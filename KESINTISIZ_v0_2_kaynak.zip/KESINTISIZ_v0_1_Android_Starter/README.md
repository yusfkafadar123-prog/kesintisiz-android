# KESİNTİSİZ v0.2 — Android prototipi

KESİNTİSİZ, ilk müdahale, tahliye ve sağlık tesisi arasındaki bilgi aktarımını desteklemeyi amaçlayan bir prototiptir.

## v0.2'de eklenenler
- Vaka listesinde bir kayda dokunarak ayrıntı ekranını açma
- Yaralanma/olay özeti, kritik bulgular, müdahaleler, zaman çizelgesi, tahliye bilgileri ve devir notları
- Alanları düzenleyip yerel veritabanına kaydetme
- Her kaydetmede revizyon sayısını artırma
- Room veritabanı için v1 → v2 geçişi; eski vaka kayıtlarını korumak üzere yeni alanlara varsayılan değer ekleme

## Güvenlik ve kullanım sınırları
- Şimdilik yalnızca sentetik eğitim verisi kullanın.
- Bu prototip klinik karar vermez, bakım talimatlarının yerini almaz ve kullanıcı yetkisini belirlemez.
- Şifreleme, kimlik doğrulama, güvenli yedekleme, değiştirilemez denetim kaydı, gerçek alıcı onayı ve cihazlar arası senkronizasyon henüz uygulanmamıştır.
- Bu prototip gerçek hasta bilgileri veya operasyonel gizli bilgiler için kullanılmamalıdır.

## Sonraki adımlar
1. Android derlemesini GitHub Actions ile çalıştırma ve APK'yı test etme
2. Vaka alanları ve düzenleme akışı için sentetik senaryolarla test
3. Eğitim modülü ve kaynak/lisans ekranı
4. Güvenlik ve kurum protokolleri için ayrı tasarım/inceleme
