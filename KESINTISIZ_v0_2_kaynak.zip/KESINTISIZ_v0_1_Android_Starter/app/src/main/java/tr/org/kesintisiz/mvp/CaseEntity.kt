package tr.org.kesintisiz.mvp

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cases")
data class CaseEntity(
    @PrimaryKey val caseUuid: String,
    val caseCode: String,
    val createdAtEpochMs: Long,
    val schemaVersion: Int = 2,
    val currentRevision: Long = 0,
    val injurySummary: String = "",
    val criticalFindings: String = "",
    val interventions: String = "",
    val eventTimes: String = "",
    val evacuationDetails: String = "",
    val handoverNotes: String = "",
    val updatedAtEpochMs: Long = createdAtEpochMs
)
