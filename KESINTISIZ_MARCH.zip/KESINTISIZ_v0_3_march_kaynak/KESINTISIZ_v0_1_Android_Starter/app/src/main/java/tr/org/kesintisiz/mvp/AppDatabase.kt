package tr.org.kesintisiz.mvp

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [CaseEntity::class],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun caseDao(): CaseDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE cases ADD COLUMN injurySummary TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE cases ADD COLUMN criticalFindings TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE cases ADD COLUMN interventions TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE cases ADD COLUMN eventTimes TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE cases ADD COLUMN evacuationDetails TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE cases ADD COLUMN handoverNotes TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE cases ADD COLUMN updatedAtEpochMs INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE cases SET updatedAtEpochMs = createdAtEpochMs, schemaVersion = 2")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE cases ADD COLUMN marchMassiveHemorrhage TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE cases ADD COLUMN marchAirway TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE cases ADD COLUMN marchRespiration TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE cases ADD COLUMN marchCirculation TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE cases ADD COLUMN marchHypothermiaHeadInjury TEXT NOT NULL DEFAULT ''")
                db.execSQL("UPDATE cases SET schemaVersion = 3")
            }
        }

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "kesintisiz_local.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
