package tr.org.kesintisiz.mvp

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CaseDao {
    @Query("SELECT * FROM cases ORDER BY createdAtEpochMs DESC")
    fun observeCases(): Flow<List<CaseEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertCase(case: CaseEntity)

    @Query("SELECT COUNT(*) FROM cases WHERE caseCode = :caseCode")
    suspend fun countByCode(caseCode: String): Int
}
