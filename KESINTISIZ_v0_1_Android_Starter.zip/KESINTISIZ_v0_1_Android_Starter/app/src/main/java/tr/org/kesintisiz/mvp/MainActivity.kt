package tr.org.kesintisiz.mvp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.util.UUID

class MainActivity : ComponentActivity() {
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = AppDatabase.getInstance(applicationContext)

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CaseHome(
                        dao = db.caseDao(),
                        onCreateCase = { code, onResult ->
                            lifecycleScope.launch {
                                val normalized = code.trim().uppercase()
                                when {
                                    normalized.isBlank() ->
                                        onResult("Vaka kodu boş bırakılamaz.")
                                    normalized.length > 32 ->
                                        onResult("Vaka kodu en fazla 32 karakter olabilir.")
                                    db.caseDao().countByCode(normalized) > 0 ->
                                        onResult("Bu vaka kodu zaten mevcut. Yeni bir sentetik kod kullan.")
                                    else -> {
                                        try {
                                            db.caseDao().insertCase(
                                                CaseEntity(
                                                    caseUuid = UUID.randomUUID().toString(),
                                                    caseCode = normalized,
                                                    createdAtEpochMs = System.currentTimeMillis()
                                                )
                                            )
                                            onResult("Vaka yerel veritabanına yazma işlemi tamamlandı. Kalıcılık ayrıca test edilmelidir.")
                                        } catch (e: Exception) {
                                            onResult("Kayıt başarısız oldu. Hata ayrıntısı: ${e.javaClass.simpleName}")
                                        }
                                    }
                                }
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun CaseHome(
    dao: CaseDao,
    onCreateCase: (String, (String) -> Unit) -> Unit
) {
    val cases by dao.observeCases().collectAsState(initial = emptyList())
    var caseCode by remember { mutableStateOf("SYN-0001") }
    var feedback by remember { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "KESİNTİSİZ",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Text("v0.1 · Sentetik vaka kayıt prototipi")
            Card(colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.secondaryContainer
            )) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("TEST MODU", fontWeight = FontWeight.Bold)
                    Text(
                        "Yalnızca sentetik veri kullanın. Bu başlangıç sürümünde " +
                            "klinik olay günlüğü, şifreleme ve gerçek devir onayı uygulanmamıştır."
                    )
                }
            }

            OutlinedTextField(
                value = caseCode,
                onValueChange = { caseCode = it },
                label = { Text("Sentetik vaka kodu") },
                supportingText = { Text("Örnek: SYN-0001 · Gerçek hasta bilgisi girmeyin.") },
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    onCreateCase(caseCode) { result -> feedback = result }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Vaka oluştur")
            }
            feedback?.let {
                Text(it, style = MaterialTheme.typography.bodyMedium)
            }

            Divider()
            Row(modifier = Modifier.fillMaxWidth()) {
                Text("Yerel vaka listesi", fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("${cases.size} kayıt")
            }

            if (cases.isEmpty()) {
                Text("Henüz vaka yok. İlk sentetik vakayı oluştur.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(cases, key = { it.caseUuid }) { item ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(
                                Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(item.caseCode, fontWeight = FontWeight.Bold)
                                Text("Sürüm: ${item.currentRevision}")
                                Text("Şema: ${item.schemaVersion}")
                                Text("UUID: ${item.caseUuid}")
                                Text("Oluşturulma zamanı (cihaz saati): ${item.createdAtEpochMs}")
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "Not: Veritabanı yereldir. Uygulama burada derlenmedi veya cihazda test edilmedi; " +
                    "uçak modu ve yeniden başlatma testlerini ayrıca yapın.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
