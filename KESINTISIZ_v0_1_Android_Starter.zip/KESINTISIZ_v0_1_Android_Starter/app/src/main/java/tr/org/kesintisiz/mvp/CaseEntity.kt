package tr.org.kesintisiz.mvp

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cases")
data class CaseEntity(
    @PrimaryKey val caseUuid: String,
    val caseCode: String,
    val createdAtEpochMs: Long,
    val schemaVersion: Int = 1,
    val currentRevision: Long = 0
)
