package tr.org.kesintisiz.mvp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.util.UUID

class MainActivity : ComponentActivity() {
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = AppDatabase.getInstance(applicationContext)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CaseHome(dao = db.caseDao())
                }
            }
        }
    }
}

@Composable
private fun CaseHome(dao: CaseDao) {
    val cases by dao.observeCases().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var caseCode by remember { mutableStateOf("SYN-0001") }
    var feedback by remember { mutableStateOf<String?>(null) }
    var selectedCase by remember { mutableStateOf<CaseEntity?>(null) }

    Scaffold { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("KESİNTİSİZ", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("v0.2 · Vaka ayrıntısı ve düzenleme prototipi")
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("TEST MODU", fontWeight = FontWeight.Bold)
                    Text("Yalnızca sentetik veri kullanın. Bu sürüm klinik karar vermez; şifreleme ve gerçek devir onayı henüz uygulanmamıştır.")
                }
            }
            OutlinedTextField(
                value = caseCode,
                onValueChange = { caseCode = it },
                label = { Text("Sentetik vaka kodu") },
                supportingText = { Text("Örnek: SYN-0001 · Gerçek hasta bilgisi girmeyin.") },
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    val normalized = caseCode.trim().uppercase()
                    scope.launch {
                        when {
                            normalized.isBlank() -> feedback = "Vaka kodu boş bırakılamaz."
                            normalized.length > 32 -> feedback = "Vaka kodu en fazla 32 karakter olabilir."
                            dao.countByCode(normalized) > 0 -> feedback = "Bu vaka kodu zaten mevcut. Yeni bir sentetik kod kullan."
                            else -> try {
                                val now = System.currentTimeMillis()
                                dao.insertCase(CaseEntity(
                                    caseUuid = UUID.randomUUID().toString(),
                                    caseCode = normalized,
                                    createdAtEpochMs = now,
                                    updatedAtEpochMs = now
                                ))
                                feedback = "Vaka kaydedildi. Ayrıntıları açmak için listedeki vakaya dokun."
                            } catch (e: Exception) {
                                feedback = "Kayıt başarısız: ${e.javaClass.simpleName}"
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Vaka oluştur") }
            feedback?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
            Divider()
            Row(modifier = Modifier.fillMaxWidth()) {
                Text("Yerel vaka listesi", fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("${cases.size} kayıt")
            }
            if (cases.isEmpty()) {
                Text("Henüz vaka yok. İlk sentetik vakayı oluştur.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                    items(cases, key = { it.caseUuid }) { item ->
                        Card(modifier = Modifier.fillMaxWidth().clickable { selectedCase = item }) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(item.caseCode, fontWeight = FontWeight.Bold)
                                Text("${if (item.injurySummary.isBlank()) "Yaralanma bilgisi eklenmedi" else item.injurySummary}")
                                Text("Revizyon: ${item.currentRevision} · Ayrıntıları açmak için dokun")
                            }
                        }
                    }
                }
            }
            Text("Yerel prototip · Gerçek hasta veya operasyonel gizli veri kullanmayın.", style = MaterialTheme.typography.bodySmall)
        }
    }

    selectedCase?.let { current ->
        CaseDetailDialog(
            caseEntity = current,
            onDismiss = { selectedCase = null },
            onSave = { updated ->
                scope.launch {
                    try {
                        dao.updateCase(updated)
                        feedback = "${updated.caseCode} güncellendi."
                        selectedCase = null
                    } catch (e: Exception) {
                        feedback = "Güncelleme başarısız: ${e.javaClass.simpleName}"
                    }
                }
            }
        )
    }
}

@Composable
private fun CaseDetailDialog(
    caseEntity: CaseEntity,
    onDismiss: () -> Unit,
    onSave: (CaseEntity) -> Unit
) {
    var injury by remember(caseEntity.caseUuid) { mutableStateOf(caseEntity.injurySummary) }
    var findings by remember(caseEntity.caseUuid) { mutableStateOf(caseEntity.criticalFindings) }
    var interventions by remember(caseEntity.caseUuid) { mutableStateOf(caseEntity.interventions) }
    var times by remember(caseEntity.caseUuid) { mutableStateOf(caseEntity.eventTimes) }
    var evacuation by remember(caseEntity.caseUuid) { mutableStateOf(caseEntity.evacuationDetails) }
    var handover by remember(caseEntity.caseUuid) { mutableStateOf(caseEntity.handoverNotes) }
    var marchM by remember(caseEntity.caseUuid) { mutableStateOf(caseEntity.marchMassiveHemorrhage) }
    var marchA by remember(caseEntity.caseUuid) { mutableStateOf(caseEntity.marchAirway) }
    var marchR by remember(caseEntity.caseUuid) { mutableStateOf(caseEntity.marchRespiration) }
    var marchC by remember(caseEntity.caseUuid) { mutableStateOf(caseEntity.marchCirculation) }
    var marchH by remember(caseEntity.caseUuid) { mutableStateOf(caseEntity.marchHypothermiaHeadInjury) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Vaka ayrıntısı · ${caseEntity.caseCode}") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Yalnızca sentetik eğitim verisi girin. Bu form, klinik öneri veya yetki dışı işlem talimatı vermez.", style = MaterialTheme.typography.bodySmall)
                DetailField("Yaralanma / olay özeti", injury, { injury = it }, "Örnek: senaryo yaralanmasının kısa özeti")
                DetailField("Kritik bulgular", findings, { findings = it }, "Gözlenen bulgular ve tekrar değerlendirme notları")
                DetailField("Yapılan müdahaleler", interventions, { interventions = it }, "Müdahale, uygulayan rol ve yanıt bilgisi")
                DetailField("Zaman çizelgesi", times, { times = it }, "Olay, değerlendirme ve müdahale saatleri")
                DetailField("Tahliye bilgileri", evacuation, { evacuation = it }, "Tahliye durumu, hedef ve teslim zamanı")
                DetailField("Devir notları", handover, { handover = it }, "Alıcıya aktarılacak kritik bilgiler ve eksikler")
                Divider()
                Text("MARCH değerlendirmesi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Yalnızca sentetik eğitim verisi gir.", style = MaterialTheme.typography.bodySmall)
                DetailField("M — Masif kanama", marchM, { marchM = it }, "Bulgu, işlem ve yeniden değerlendirme")
                DetailField("A — Havayolu", marchA, { marchA = it }, "Bulgu, işlem ve yeniden değerlendirme")
                DetailField("R — Solunum", marchR, { marchR = it }, "Bulgu, işlem ve yeniden değerlendirme")
                DetailField("C — Dolaşım", marchC, { marchC = it }, "Bulgu, işlem ve yeniden değerlendirme")
                DetailField("H — Hipotermi / kafa travması", marchH, { marchH = it }, "Bulgu, işlem ve yeniden değerlendirme")
                Divider()
                Text("Oluşturulma: ${caseEntity.createdAtEpochMs}", style = MaterialTheme.typography.bodySmall)
                Text("Son güncelleme: ${caseEntity.updatedAtEpochMs}", style = MaterialTheme.typography.bodySmall)
                Text("Revizyon: ${caseEntity.currentRevision}", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(caseEntity.copy(
                    schemaVersion = 2,
                    currentRevision = caseEntity.currentRevision + 1,
                    injurySummary = injury.trim(),
                    criticalFindings = findings.trim(),
                    interventions = interventions.trim(),
                    eventTimes = times.trim(),
                    evacuationDetails = evacuation.trim(),
                    handoverNotes = handover.trim(),
                    marchMassiveHemorrhage = marchM.trim(),
                    marchAirway = marchA.trim(),
                    marchRespiration = marchR.trim(),
                    marchCirculation = marchC.trim(),
                    marchHypothermiaHeadInjury = marchH.trim(),
                    schemaVersion = 3,
                    updatedAtEpochMs = System.currentTimeMillis()
                ))
            }) { Text("Kaydet") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç") } }
    )
}

@Composable
private fun DetailField(label: String, value: String, onValueChange: (String) -> Unit, hint: String) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        placeholder = { Text(hint) },
        modifier = Modifier.fillMaxWidth(),
        minLines = 2,
        maxLines = 5
    )
}
